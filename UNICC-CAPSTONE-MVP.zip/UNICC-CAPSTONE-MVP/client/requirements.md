## Packages
framer-motion | Smooth transitions and layout animations
clsx | Conditional class merging
tailwind-merge | Tailwind class conflict resolution

## Notes
- Theme: UN/Governmental professional style (Blue/Gray/White)
- Using "Inter" for UI text and "Merriweather" for formal headings
- Mocking data aggregation on the client if backend implementation is simple
