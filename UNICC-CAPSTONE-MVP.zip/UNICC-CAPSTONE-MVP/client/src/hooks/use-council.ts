import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export function useSystem() {
  return useQuery({
    queryKey: ["/api/system"],
  });
}

export function useExperts() {
  return useQuery({
    queryKey: ["/api/experts"],
  });
}

export function useEvaluations() {
  return useQuery({
    queryKey: ["/api/evaluations"],
  });
}

export function useCouncilAggregation() {
  return useMutation({
    mutationFn: async (selectedExpertIds: string[]) => {
      const res = await apiRequest("POST", "/api/council/aggregate", { selectedExpertIds });
      return res.json();
    },
  });
}

export function useCreateEvaluation() {
  return useMutation({
    mutationFn: async (data: {
      agentName: string;
      description: string;
      context: string;
      requestedTests: string[];
    }) => {
      const res = await apiRequest("POST", "/api/evaluations", data);
      return res.json();
    },
  });
}
