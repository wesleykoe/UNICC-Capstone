import { useState } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Header } from "@/components/Header";
import { TabNav, type TabId } from "@/components/TabNav";
import { useSystem, useExperts, useEvaluations } from "@/hooks/use-council";
import DashboardTab from "@/pages/DashboardTab";
import RunEvaluationTab from "@/pages/RunEvaluationTab";
import ExpertPanelTab from "@/pages/ExpertPanelTab";
import CouncilDecisionTab from "@/pages/CouncilDecisionTab";
import ReportsTab from "@/pages/ReportsTab";
import { Loader2 } from "lucide-react";

function AppContent() {
  const [activeTab, setActiveTab] = useState<TabId>("dashboard");
  const { data: system, isLoading: sysLoading } = useSystem();
  const { data: experts, isLoading: expLoading } = useExperts();
  const { data: evaluations, isLoading: evalLoading } = useEvaluations();

  const isLoading = sysLoading || expLoading || evalLoading;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header system={system as any} />
      <TabNav activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="flex-1 container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center space-y-3">
              <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto" />
              <p className="text-sm text-muted-foreground">Loading council data...</p>
            </div>
          </div>
        ) : (
          <>
            {activeTab === "dashboard" && (
              <DashboardTab system={system as any} experts={experts as any} evaluations={evaluations as any} />
            )}
            {activeTab === "evaluation" && <RunEvaluationTab />}
            {activeTab === "experts" && <ExpertPanelTab experts={experts as any} />}
            {activeTab === "decision" && <CouncilDecisionTab experts={experts as any} />}
            {activeTab === "reports" && <ReportsTab evaluations={evaluations as any} />}
          </>
        )}
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
