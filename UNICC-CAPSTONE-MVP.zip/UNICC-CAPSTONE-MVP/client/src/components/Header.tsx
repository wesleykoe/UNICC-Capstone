import { ShieldCheck, Globe } from "lucide-react";
import type { System } from "@shared/schema";

interface HeaderProps {
  system?: System;
}

export function Header({ system }: HeaderProps) {
  const statusColor = system?.status === "Operational"
    ? "bg-emerald-500"
    : system?.status === "High Risk"
      ? "bg-red-500"
      : "bg-amber-500";

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50" data-testid="header">
      <div className="container mx-auto px-4 h-14 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary text-primary-foreground p-2 rounded-md">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-semibold leading-none tracking-tight text-foreground">
              UNICC AI Safety Council
            </h1>
            <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider mt-0.5">
              Council of Experts Architecture
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap justify-end">
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-muted rounded-md border border-border">
            <div className={`w-2 h-2 rounded-full ${statusColor}`} />
            <span className="text-xs font-medium text-muted-foreground" data-testid="text-system-status">
              {system?.status || "Loading..."}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <Globe className="w-3.5 h-3.5" />
            <span>Global</span>
          </div>
        </div>
      </div>
    </header>
  );
}
