import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/Badge";
import { Checkbox } from "@/components/ui/checkbox";
import { motion } from "framer-motion";
import type { ExpertResponse } from "@shared/routes";
import { Check, Shield, AlertTriangle, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

interface ExpertCardProps {
  expert: ExpertResponse;
  isSelected: boolean;
  onToggle: (id: string) => void;
  index: number;
}

export function ExpertCard({ expert, isSelected, onToggle, index }: ExpertCardProps) {
  // Determine verdict visual style
  const verdictConfig = {
    PASS: { color: "text-emerald-700 bg-emerald-50 border-emerald-200", icon: Shield },
    FAIL: { color: "text-red-700 bg-red-50 border-red-200", icon: AlertTriangle },
    PENDING: { color: "text-amber-700 bg-amber-50 border-amber-200", icon: FileText },
  }[expert.verdict] || { color: "text-slate-700 bg-slate-50 border-slate-200", icon: FileText };

  const VerdictIcon = verdictConfig.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
    >
      <Card 
        className={cn(
          "h-full transition-all duration-300 border hover:shadow-md cursor-pointer relative group overflow-hidden",
          isSelected ? "border-primary ring-1 ring-primary shadow-md bg-white" : "border-border bg-slate-50/50 opacity-80 hover:opacity-100"
        )}
        onClick={() => onToggle(expert.id)}
      >
        {/* Selection Indicator Overlay */}
        <div className={cn(
          "absolute top-0 right-0 p-2 z-10 transition-opacity duration-200",
          isSelected ? "opacity-100" : "opacity-0 group-hover:opacity-100"
        )}>
           <Checkbox 
            checked={isSelected} 
            onCheckedChange={() => onToggle(expert.id)}
            className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
          />
        </div>

        <CardContent className="p-5 space-y-4">
          {/* Header */}
          <div className="flex justify-between items-start">
            <div>
              <div className="text-xs font-bold text-primary uppercase tracking-wider mb-1">
                {expert.role}
              </div>
              <h3 className="font-serif text-lg font-bold text-slate-900 leading-tight">
                {expert.name}
              </h3>
            </div>
            <Badge variant="outline" className={cn("ml-2 font-mono text-xs", verdictConfig.color)}>
              Score: {expert.score}
            </Badge>
          </div>

          {/* Description */}
          <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">
            {expert.description}
          </p>

          {/* Findings List */}
          <div className="space-y-2">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Key Findings
            </h4>
            <ul className="space-y-1.5">
              {expert.findings.slice(0, 2).map((finding, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                  <Check className="w-3 h-3 text-primary mt-0.5 shrink-0" />
                  <span className="line-clamp-2">{finding}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Verdict Footer */}
          <div className={cn("mt-4 p-2 rounded-lg border flex items-center gap-2", verdictConfig.color)}>
            <VerdictIcon className="w-4 h-4 shrink-0" />
            <span className="text-xs font-bold uppercase tracking-wide">
              {expert.verdict}
            </span>
            {expert.recommendation && (
              <span className="text-[10px] ml-auto opacity-80 truncate max-w-[120px]">
                {expert.recommendation}
              </span>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
