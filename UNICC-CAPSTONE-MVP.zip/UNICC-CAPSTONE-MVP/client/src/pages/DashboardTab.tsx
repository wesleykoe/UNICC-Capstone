import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, AlertTriangle, CheckCircle2, Clock, BarChart3, Activity } from "lucide-react";
import type { System, Expert, Evaluation } from "@shared/schema";

interface DashboardTabProps {
  system?: System;
  experts?: Expert[];
  evaluations?: Evaluation[];
}

export default function DashboardTab({ system, experts, evaluations }: DashboardTabProps) {
  const totalEvals = evaluations?.length || 0;
  const tier1Count = evaluations?.filter(e => e.tier === 1).length || 0;
  const tier2Count = evaluations?.filter(e => e.tier === 2).length || 0;
  const tier3Count = evaluations?.filter(e => e.tier === 3).length || 0;
  const approvedCount = evaluations?.filter(e => e.status === "APPROVED").length || 0;
  const pendingCount = evaluations?.filter(e => e.status === "PENDING").length || 0;

  const statusColor = system?.status === "Operational"
    ? "text-emerald-700 bg-emerald-50"
    : system?.status === "High Risk"
      ? "text-red-700 bg-red-50"
      : "text-amber-700 bg-amber-50";

  return (
    <div className="space-y-6" data-testid="dashboard-tab">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card data-testid="card-system-status">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">System Status</span>
              <Activity className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-sm font-semibold ${statusColor}`}>
              {system?.status || "Unknown"}
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-total-evaluations">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Evaluations</span>
              <BarChart3 className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold text-foreground">{totalEvals}</div>
            <p className="text-xs text-muted-foreground mt-0.5">{approvedCount} approved</p>
          </CardContent>
        </Card>

        <Card data-testid="card-pending">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Pending</span>
              <Clock className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold text-foreground">{pendingCount}</div>
            <p className="text-xs text-muted-foreground mt-0.5">awaiting review</p>
          </CardContent>
        </Card>

        <Card data-testid="card-experts-active">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Experts</span>
              <ShieldCheck className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold text-foreground">{experts?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-0.5">active panelists</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1" data-testid="card-risk-distribution">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">Risk Tier Distribution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <TierBar label="Tier 1 — Low" count={tier1Count} total={totalEvals || 1} color="bg-emerald-500" />
            <TierBar label="Tier 2 — Moderate" count={tier2Count} total={totalEvals || 1} color="bg-amber-500" />
            <TierBar label="Tier 3 — High" count={tier3Count} total={totalEvals || 1} color="bg-red-500" />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2" data-testid="card-recent-evaluations">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">Recent Evaluations</CardTitle>
          </CardHeader>
          <CardContent>
            {!evaluations || evaluations.length === 0 ? (
              <p className="text-sm text-muted-foreground py-6 text-center">No evaluations recorded yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm" data-testid="table-evaluations">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Agent</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Score</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Tier</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {evaluations.slice(0, 8).map((ev) => (
                      <tr key={ev.id} className="border-b border-border last:border-b-0" data-testid={`row-evaluation-${ev.id}`}>
                        <td className="py-2.5 px-2 font-medium text-foreground">{ev.agentName}</td>
                        <td className="py-2.5 px-2 text-muted-foreground">{ev.score ?? "—"}</td>
                        <td className="py-2.5 px-2">
                          <TierBadge tier={ev.tier} />
                        </td>
                        <td className="py-2.5 px-2">
                          <StatusBadge status={ev.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {experts && experts.length > 0 && (
        <Card data-testid="card-council-summary">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">Council Panel Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {experts.map((expert) => (
                <div key={expert.id} className="flex items-center gap-3 p-3 bg-muted rounded-md border border-border" data-testid={`panel-expert-${expert.id}`}>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{expert.name}</p>
                    <p className="text-xs text-muted-foreground">{expert.role}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-lg font-bold text-foreground">{expert.score}</div>
                    <StatusBadge status={expert.verdict} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function TierBar({ label, count, total, color }: { label: string; count: number; total: number; color: string }) {
  const pct = Math.round((count / total) * 100);
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-semibold text-foreground">{count}</span>
      </div>
      <div className="w-full bg-muted rounded-full h-2">
        <div className={`${color} h-2 rounded-full transition-all duration-500`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function TierBadge({ tier }: { tier: number | null }) {
  if (tier === null) return <span className="text-muted-foreground">—</span>;
  const config: Record<number, string> = {
    1: "bg-emerald-50 text-emerald-700",
    2: "bg-amber-50 text-amber-700",
    3: "bg-red-50 text-red-700",
    4: "bg-red-100 text-red-800",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${config[tier] || "bg-muted text-muted-foreground"}`}>
      Tier {tier}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, string> = {
    APPROVED: "bg-emerald-50 text-emerald-700",
    PASS: "bg-emerald-50 text-emerald-700",
    CONDITIONAL: "bg-amber-50 text-amber-700",
    PENDING: "bg-amber-50 text-amber-700",
    REJECTED: "bg-red-50 text-red-700",
    FLAG: "bg-red-50 text-red-700",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${config[status] || "bg-muted text-muted-foreground"}`}>
      {status}
    </span>
  );
}
