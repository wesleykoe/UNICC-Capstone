import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Shield, FileText, AlertTriangle, ChevronDown, ChevronUp, Check } from "lucide-react";
import type { Expert } from "@shared/schema";

interface ExpertPanelTabProps {
  experts?: Expert[];
}

export default function ExpertPanelTab({ experts }: ExpertPanelTabProps) {
  if (!experts || experts.length === 0) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <p>No expert data available.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="expert-panel-tab">
      <p className="text-sm text-muted-foreground">
        Independent judge outputs from each expert module in the council.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {experts.map((expert) => (
          <ExpertDetailCard key={expert.id} expert={expert} />
        ))}
      </div>
    </div>
  );
}

function ExpertDetailCard({ expert }: { expert: Expert }) {
  const [isOpen, setIsOpen] = useState(false);

  const verdictConfig: Record<string, { color: string; bg: string; icon: typeof Shield }> = {
    PASS: { color: "text-emerald-700", bg: "bg-emerald-50 border-emerald-200", icon: Shield },
    PENDING: { color: "text-amber-700", bg: "bg-amber-50 border-amber-200", icon: FileText },
    FLAG: { color: "text-red-700", bg: "bg-red-50 border-red-200", icon: AlertTriangle },
  };

  const config = verdictConfig[expert.verdict] || verdictConfig.PENDING;
  const VerdictIcon = config.icon;

  const tierLabel = expert.tier === 1 ? "Low Risk" : expert.tier === 2 ? "Moderate Risk" : "High Risk";
  const tierColor = expert.tier === 1 ? "bg-emerald-50 text-emerald-700" : expert.tier === 2 ? "bg-amber-50 text-amber-700" : "bg-red-50 text-red-700";

  return (
    <Card className="flex flex-col" data-testid={`expert-card-${expert.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <CardTitle className="text-base font-semibold text-foreground">
              {expert.name} — {expert.role}
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">{expert.description}</p>
          </div>
          <Badge variant="outline" className="text-[10px] shrink-0">Expert Output</Badge>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-muted p-3 rounded-md text-center">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Tier</p>
            <p className={`text-sm font-bold mt-1 ${tierColor} inline-block px-2 py-0.5 rounded`}>Tier {expert.tier}</p>
          </div>
          <div className="bg-muted p-3 rounded-md text-center">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Score</p>
            <p className="text-lg font-bold text-foreground mt-1">{expert.score}</p>
          </div>
          <div className="bg-muted p-3 rounded-md text-center">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Verdict</p>
            <div className={`flex items-center justify-center gap-1 mt-1 ${config.color}`}>
              <VerdictIcon className="w-3.5 h-3.5" />
              <span className="text-xs font-bold uppercase">{expert.verdict}</span>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h4 className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Key Findings</h4>
          <ul className="space-y-1.5">
            {expert.findings.map((finding, idx) => (
              <li key={idx} className="flex items-start gap-2 text-xs text-foreground leading-relaxed">
                <Check className="w-3 h-3 text-primary mt-0.5 shrink-0" />
                <span>{finding}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-auto pt-2">
          <Collapsible open={isOpen} onOpenChange={setIsOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="w-full text-xs" data-testid={`button-reasoning-${expert.id}`}>
                {isOpen ? <ChevronUp className="w-3.5 h-3.5 mr-1.5" /> : <ChevronDown className="w-3.5 h-3.5 mr-1.5" />}
                {isOpen ? "Hide" : "View"} Detailed Reasoning
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="mt-2 p-3 bg-muted rounded-md border border-border text-xs text-muted-foreground leading-relaxed space-y-2" data-testid={`reasoning-${expert.id}`}>
                <p><strong className="text-foreground">Tier Assessment:</strong> {tierLabel} — Based on comprehensive evaluation of {expert.findings.length} key finding(s).</p>
                {expert.recommendation && (
                  <p><strong className="text-foreground">Recommendation:</strong> {expert.recommendation}</p>
                )}
                <p><strong className="text-foreground">Confidence:</strong> Score of {expert.score}/100 indicates a {expert.score >= 80 ? "high" : expert.score >= 60 ? "moderate" : "low"} confidence assessment.</p>
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      </CardContent>
    </Card>
  );
}
