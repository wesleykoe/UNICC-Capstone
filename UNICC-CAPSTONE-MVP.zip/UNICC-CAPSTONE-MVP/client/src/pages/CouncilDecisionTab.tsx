import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle2, AlertTriangle, XCircle, Gavel, ShieldAlert } from "lucide-react";
import { useCouncilAggregation } from "@/hooks/use-council";
import type { Expert, AggregationResponse } from "@shared/schema";

interface CouncilDecisionTabProps {
  experts?: Expert[];
}

export default function CouncilDecisionTab({ experts }: CouncilDecisionTabProps) {
  const { mutate: aggregate, data: aggregation, isPending } = useCouncilAggregation();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  useEffect(() => {
    if (experts) {
      const ids = experts.map(e => e.id);
      setSelectedIds(ids);
      aggregate(ids);
    }
  }, [experts]);

  const toggleExpert = (id: string) => {
    const next = selectedIds.includes(id) ? selectedIds.filter(x => x !== id) : [...selectedIds, id];
    setSelectedIds(next);
    aggregate(next);
  };

  const decisionConfig: Record<string, { icon: typeof CheckCircle2; colorBg: string; colorText: string }> = {
    APPROVED: { icon: CheckCircle2, colorBg: "bg-emerald-50 border-emerald-300", colorText: "text-emerald-700" },
    CONDITIONAL: { icon: AlertTriangle, colorBg: "bg-amber-50 border-amber-300", colorText: "text-amber-700" },
    REJECTED: { icon: XCircle, colorBg: "bg-red-50 border-red-300", colorText: "text-red-700" },
  };

  const config = decisionConfig[aggregation?.decision || ""] || { icon: Gavel, colorBg: "bg-muted border-border", colorText: "text-muted-foreground" };
  const DecisionIcon = config.icon;

  return (
    <div className="space-y-6" data-testid="council-decision-tab">
      <div className="flex flex-wrap gap-3 items-center">
        <span className="text-sm text-muted-foreground font-medium">Select experts for consensus:</span>
        {experts?.map(expert => (
          <label key={expert.id} className="flex items-center gap-2 px-3 py-2 rounded-md border border-border bg-card cursor-pointer" data-testid={`toggle-expert-${expert.id}`}>
            <Checkbox
              checked={selectedIds.includes(expert.id)}
              onCheckedChange={() => toggleExpert(expert.id)}
            />
            <span className="text-sm font-medium text-foreground">{expert.name}</span>
            <span className="text-xs text-muted-foreground">({expert.role})</span>
          </label>
        ))}
      </div>

      <div className="max-w-2xl mx-auto">
        <Card className="border-2" data-testid="card-final-decision">
          <CardHeader className="text-center pb-4">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Gavel className="w-5 h-5 text-muted-foreground" />
              <CardTitle className="text-lg font-semibold">Council Decision</CardTitle>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {isPending ? (
              <div className="text-center py-8">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">Calculating consensus...</p>
              </div>
            ) : aggregation ? (
              <>
                <div className={`p-6 rounded-md border-2 text-center ${config.colorBg}`}>
                  <DecisionIcon className={`w-12 h-12 mx-auto mb-3 ${config.colorText}`} />
                  <h2 className={`text-2xl font-bold uppercase tracking-tight ${config.colorText}`} data-testid="text-decision">
                    {aggregation.decision}
                  </h2>
                  <p className={`text-sm mt-1 ${config.colorText} opacity-80`} data-testid="text-basis">
                    {aggregation.basis}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-muted p-4 rounded-md text-center">
                    <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Final Tier</p>
                    <p className="text-2xl font-bold text-foreground mt-1" data-testid="text-final-tier">
                      {aggregation.finalTier !== null ? `Tier ${aggregation.finalTier}` : "—"}
                    </p>
                  </div>
                  <div className="bg-muted p-4 rounded-md text-center">
                    <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Experts</p>
                    <p className="text-2xl font-bold text-foreground mt-1">{selectedIds.length} / {experts?.length || 0}</p>
                  </div>
                </div>

                {aggregation.mandatoryReview && (
                  <div className="flex items-center gap-3 p-3 bg-amber-50 border border-amber-200 rounded-md" data-testid="mandatory-review-flag">
                    <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0" />
                    <div>
                      <p className="text-sm font-semibold text-amber-800">Mandatory Human Review Required</p>
                      <p className="text-xs text-amber-600">Tier 3 risk level triggers ASRB human-in-the-loop review before certification.</p>
                    </div>
                  </div>
                )}

                <div>
                  <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">Consensus Rationale</h4>
                  <ul className="space-y-2">
                    {aggregation.rationale.map((r, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <p className="text-[10px] text-muted-foreground text-center pt-2">
                  Aggregation policy: Final Tier = max(selected tiers), with gate rules for Tier 4 (reject) and Tier 3 (review).
                </p>
              </>
            ) : (
              <p className="text-center text-sm text-muted-foreground py-8">Select at least one expert to view the council decision.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
