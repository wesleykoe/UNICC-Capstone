import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, FileJson, Clock, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Evaluation } from "@shared/schema";

interface ReportsTabProps {
  evaluations?: Evaluation[];
}

export default function ReportsTab({ evaluations }: ReportsTabProps) {
  const { toast } = useToast();

  const handleGenerate = (type: string) => {
    toast({
      title: `${type.toUpperCase()} Report`,
      description: `Report generation initiated. This is a demo — in the integrated system, reports will be downloadable.`,
    });
  };

  return (
    <div className="space-y-6" data-testid="reports-tab">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card data-testid="card-generate-reports">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">Generate Reports</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start gap-3" onClick={() => handleGenerate("pdf")} data-testid="button-generate-pdf">
              <FileText className="w-4 h-4 text-red-500" />
              <div className="text-left">
                <p className="text-sm font-medium">Generate PDF Report</p>
                <p className="text-xs text-muted-foreground">Full evaluation summary with charts</p>
              </div>
              <Download className="w-4 h-4 ml-auto text-muted-foreground" />
            </Button>

            <Button variant="outline" className="w-full justify-start gap-3" onClick={() => handleGenerate("json")} data-testid="button-generate-json">
              <FileJson className="w-4 h-4 text-blue-500" />
              <div className="text-left">
                <p className="text-sm font-medium">Export JSON Data</p>
                <p className="text-xs text-muted-foreground">Machine-readable evaluation data</p>
              </div>
              <Download className="w-4 h-4 ml-auto text-muted-foreground" />
            </Button>
          </CardContent>
        </Card>

        <Card data-testid="card-audit-log">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-muted-foreground" />
              <CardTitle className="text-sm font-semibold">Governance Audit Log</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <AuditEntry time="System initialized" action="Council of Experts framework loaded" />
              <AuditEntry time="Expert panel configured" action="Team6, Team8, Team1 registered" />
              <AuditEntry time="Aggregation policy" action="Conservative (max tier) with gate rules" />
              {evaluations && evaluations.length > 0 && (
                <AuditEntry time="Latest evaluation" action={`${evaluations[0].agentName} — ${evaluations[0].status}`} />
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card data-testid="card-evaluation-history">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold">Evaluation History</CardTitle>
        </CardHeader>
        <CardContent>
          {!evaluations || evaluations.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">No evaluations recorded yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm" data-testid="table-history">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Agent</th>
                    <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Context</th>
                    <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Score</th>
                    <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Tier</th>
                    <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
                    <th className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {evaluations.map((ev) => (
                    <tr key={ev.id} className="border-b border-border last:border-b-0" data-testid={`row-history-${ev.id}`}>
                      <td className="py-2.5 px-2 font-medium text-foreground">{ev.agentName}</td>
                      <td className="py-2.5 px-2 text-muted-foreground">{ev.context}</td>
                      <td className="py-2.5 px-2 text-foreground">{ev.score ?? "—"}</td>
                      <td className="py-2.5 px-2">
                        {ev.tier ? (
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${
                            ev.tier === 1 ? "bg-emerald-50 text-emerald-700" :
                            ev.tier === 2 ? "bg-amber-50 text-amber-700" :
                            "bg-red-50 text-red-700"
                          }`}>Tier {ev.tier}</span>
                        ) : "—"}
                      </td>
                      <td className="py-2.5 px-2">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          ev.status === "APPROVED" ? "bg-emerald-50 text-emerald-700" :
                          ev.status === "CONDITIONAL" ? "bg-amber-50 text-amber-700" :
                          ev.status === "REJECTED" ? "bg-red-50 text-red-700" :
                          "bg-muted text-muted-foreground"
                        }`}>{ev.status}</span>
                      </td>
                      <td className="py-2.5 px-2 text-muted-foreground text-xs">
                        {ev.timestamp ? new Date(ev.timestamp).toLocaleDateString() : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function AuditEntry({ time, action }: { time: string; action: string }) {
  return (
    <div className="flex items-start gap-3">
      <Clock className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
      <div>
        <p className="text-xs font-semibold text-foreground">{time}</p>
        <p className="text-xs text-muted-foreground">{action}</p>
      </div>
    </div>
  );
}
