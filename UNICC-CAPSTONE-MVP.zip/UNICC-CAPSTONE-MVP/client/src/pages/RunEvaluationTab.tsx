import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCreateEvaluation } from "@/hooks/use-council";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Play, Loader2, CheckCircle2, Terminal } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const CONTEXTS = [
  "UN operations",
  "Humanitarian",
  "Internal tools",
  "Peacekeeping",
  "Health services",
  "Education",
];

const TESTS = [
  { id: "fairness", label: "Fairness" },
  { id: "robustness", label: "Robustness" },
  { id: "privacy", label: "Privacy" },
  { id: "transparency", label: "Transparency" },
  { id: "human_oversight", label: "Human Oversight" },
];

export default function RunEvaluationTab() {
  const { toast } = useToast();
  const createEval = useCreateEvaluation();

  const [agentName, setAgentName] = useState("");
  const [description, setDescription] = useState("");
  const [context, setContext] = useState("");
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [progress, setProgress] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  const toggleTest = (testId: string) => {
    setSelectedTests(prev =>
      prev.includes(testId) ? prev.filter(t => t !== testId) : [...prev, testId]
    );
  };

  const canSubmit = agentName.trim() && description.trim() && context && selectedTests.length > 0;

  const handleRun = async () => {
    if (!canSubmit) return;

    setIsRunning(true);
    setProgress(0);
    setLogs(["[INIT] Starting council evaluation..."]);

    const steps = [
      { pct: 15, msg: "[LOAD] Loading expert configurations..." },
      { pct: 30, msg: `[TEST] Running ${selectedTests.length} test suite(s)...` },
      { pct: 50, msg: "[TEAM6] Technical Agent analysis complete." },
      { pct: 65, msg: "[TEAM8] Governance Workflow check in progress..." },
      { pct: 80, msg: "[TEAM1] Benchmark Framework scoring..." },
      { pct: 90, msg: "[AGG] Aggregating council consensus..." },
    ];

    for (const step of steps) {
      await new Promise(r => setTimeout(r, 600 + Math.random() * 400));
      setProgress(step.pct);
      setLogs(prev => [...prev, step.msg]);
    }

    const score = 60 + Math.floor(Math.random() * 30);
    const tier = score >= 85 ? 1 : score >= 70 ? 2 : 3;
    const status = tier <= 2 ? "APPROVED" : "CONDITIONAL";

    try {
      await createEval.mutateAsync({
        agentName,
        description,
        context,
        requestedTests: selectedTests,
      });

      setProgress(100);
      setLogs(prev => [...prev, `[DONE] Evaluation complete. Score: ${score}, Tier: ${tier}, Status: ${status}`]);

      queryClient.invalidateQueries({ queryKey: ["/api/evaluations"] });

      toast({ title: "Evaluation Complete", description: `${agentName} scored ${score} (Tier ${tier})` });
    } catch {
      setLogs(prev => [...prev, "[ERROR] Evaluation submission failed."]);
      toast({ title: "Error", description: "Failed to save evaluation.", variant: "destructive" });
    }

    setTimeout(() => setIsRunning(false), 1000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6" data-testid="evaluation-tab">
      <div className="lg:col-span-3 space-y-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">Agent Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="agent-name" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Agent Name</Label>
              <Input
                id="agent-name"
                data-testid="input-agent-name"
                placeholder="e.g. Logistics-Bot-v2"
                value={agentName}
                onChange={(e) => setAgentName(e.target.value)}
                disabled={isRunning}
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Description</Label>
              <Textarea
                id="description"
                data-testid="input-description"
                placeholder="Brief description of the AI system under evaluation..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                disabled={isRunning}
                className="resize-none"
                rows={3}
              />
            </div>

            <div>
              <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Operating Context</Label>
              <Select value={context} onValueChange={setContext} disabled={isRunning}>
                <SelectTrigger data-testid="select-context">
                  <SelectValue placeholder="Select context..." />
                </SelectTrigger>
                <SelectContent>
                  {CONTEXTS.map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 block">Requested Tests</Label>
              <div className="grid grid-cols-2 gap-3">
                {TESTS.map(test => (
                  <label
                    key={test.id}
                    className="flex items-center gap-2.5 p-3 rounded-md border border-border bg-muted/50 cursor-pointer"
                    data-testid={`checkbox-test-${test.id}`}
                  >
                    <Checkbox
                      checked={selectedTests.includes(test.id)}
                      onCheckedChange={() => toggleTest(test.id)}
                      disabled={isRunning}
                    />
                    <span className="text-sm font-medium text-foreground">{test.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-2 space-y-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">Run Council Evaluation</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              className="w-full"
              disabled={!canSubmit || isRunning}
              onClick={handleRun}
              data-testid="button-run-evaluation"
            >
              {isRunning ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Running...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Run Council Evaluation
                </>
              )}
            </Button>

            {(isRunning || progress === 100) && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Progress</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
                {progress === 100 && (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Evaluation complete
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-muted-foreground" />
              <CardTitle className="text-sm font-semibold">Live Logs</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-foreground/5 rounded-md p-3 h-52 overflow-y-auto font-mono text-xs space-y-1" data-testid="logs-area">
              {logs.length === 0 ? (
                <p className="text-muted-foreground">Waiting for evaluation to start...</p>
              ) : (
                logs.map((log, i) => (
                  <div key={i} className="text-muted-foreground">
                    <span className="text-foreground/70">{log}</span>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
