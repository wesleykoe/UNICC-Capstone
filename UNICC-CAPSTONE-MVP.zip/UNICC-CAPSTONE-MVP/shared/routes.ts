
import { z } from 'zod';
import { experts, systems, evaluations, insertEvaluationSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  experts: {
    list: {
      method: 'GET' as const,
      path: '/api/experts' as const,
      responses: {
        200: z.array(z.custom<typeof experts.$inferSelect>()),
      },
    }
  },
  systems: {
    get: {
      method: 'GET' as const,
      path: '/api/system' as const,
      responses: {
        200: z.custom<typeof systems.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  },
  evaluations: {
    list: {
      method: 'GET' as const,
      path: '/api/evaluations' as const,
      responses: {
        200: z.array(z.custom<typeof evaluations.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/evaluations' as const,
      input: insertEvaluationSchema,
      responses: {
        201: z.custom<typeof evaluations.$inferSelect>(),
        400: errorSchemas.validation,
      },
    }
  },
  council: {
    aggregate: {
      method: 'POST' as const,
      path: '/api/council/aggregate' as const,
      input: z.object({
        selectedExpertIds: z.array(z.string())
      }),
      responses: {
        200: z.object({
          finalTier: z.number().nullable(),
          decision: z.string(),
          basis: z.string(),
          rationale: z.array(z.string()),
          mandatoryReview: z.boolean()
        })
      }
    }
  },
  reports: {
    generate: {
      method: 'POST' as const,
      path: '/api/reports/:type' as const, // 'pdf' or 'json'
      responses: {
        200: z.object({ url: z.string(), filename: z.string() }),
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
