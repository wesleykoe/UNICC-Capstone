
import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const experts = pgTable("experts", {
  id: text("id").primaryKey(), // 'team6', 'team8', 'team1'
  name: text("name").notNull(),
  role: text("role").notNull(),
  description: text("description").notNull(),
  tier: integer("tier").notNull(),
  score: integer("score").notNull(),
  verdict: text("verdict").notNull(), // 'PASS', 'FLAG', 'PENDING'
  findings: jsonb("findings").$type<string[]>().notNull(),
  recommendation: text("recommendation"),
});

export const systems = pgTable("systems", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  context: text("context").notNull(),
  requestedTests: jsonb("requested_tests").$type<string[]>().notNull(),
  status: text("status").default("Operational").notNull(), // 'Operational', 'Under Review', 'High Risk'
});

export const evaluations = pgTable("evaluations", {
  id: serial("id").primaryKey(),
  agentName: text("agent_name").notNull(),
  description: text("description").notNull(),
  context: text("context").notNull(),
  requestedTests: jsonb("requested_tests").$type<string[]>().notNull(),
  score: integer("score"),
  tier: integer("tier"),
  status: text("status").default("PENDING").notNull(), // 'APPROVED', 'CONDITIONAL', 'REJECTED', 'PENDING'
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  results: jsonb("results").$type<Record<string, any>>(), // Detailed expert outputs
});

// === BASE SCHEMAS ===
export const insertExpertSchema = createInsertSchema(experts);
export const insertSystemSchema = createInsertSchema(systems);
export const insertEvaluationSchema = createInsertSchema(evaluations).omit({ id: true, timestamp: true });

// === EXPLICIT API CONTRACT TYPES ===
export type Expert = typeof experts.$inferSelect;
export type System = typeof systems.$inferSelect;
export type Evaluation = typeof evaluations.$inferSelect;

export type ExpertResponse = Expert;
export type SystemResponse = System;
export type EvaluationResponse = Evaluation;

export interface AggregationRequest {
  selectedExpertIds: string[];
}

export interface AggregationResponse {
  finalTier: number | null;
  decision: string;
  basis: string;
  rationale: string[];
  mandatoryReview: boolean;
}
