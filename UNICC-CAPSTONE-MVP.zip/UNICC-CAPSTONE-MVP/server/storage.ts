
import { 
  type Expert, 
  type System, 
  type Evaluation, 
  type AggregationResponse, 
  experts, 
  systems, 
  evaluations 
} from "@shared/schema";
import { db } from "./db";
import { eq, inArray, desc } from "drizzle-orm";

export interface IStorage {
  getExperts(): Promise<Expert[]>;
  getSystem(): Promise<System | undefined>;
  getEvaluations(): Promise<Evaluation[]>;
  createEvaluation(evaluation: Omit<Evaluation, "id" | "timestamp">): Promise<Evaluation>;
  aggregateCouncil(selectedExpertIds: string[]): Promise<AggregationResponse>;
  seed(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getExperts(): Promise<Expert[]> {
    return await db.select().from(experts);
  }

  async getSystem(): Promise<System | undefined> {
    const [system] = await db.select().from(systems).limit(1);
    return system;
  }

  async getEvaluations(): Promise<Evaluation[]> {
    return await db.select().from(evaluations).orderBy(desc(evaluations.timestamp));
  }

  async createEvaluation(insertData: any): Promise<Evaluation> {
    const [evaluation] = await db.insert(evaluations).values(insertData).returning();
    return evaluation;
  }

  async aggregateCouncil(selectedExpertIds: string[]): Promise<AggregationResponse> {
    if (selectedExpertIds.length === 0) {
      return {
        finalTier: null,
        decision: "—",
        basis: "—",
        rationale: ["No experts selected."],
        mandatoryReview: false
      };
    }

    const selectedExperts = await db.select().from(experts).where(inArray(experts.id, selectedExpertIds));
    const tiers = selectedExperts.map(e => e.tier);
    const maxTier = Math.max(...tiers);

    let decision = "APPROVED";
    let basis = "Standard Risk Profile";
    let rationale: string[] = [];
    let mandatoryReview = false;

    if (tiers.includes(4)) {
      decision = "REJECTED";
      basis = "Critical Risk Identified";
      rationale.push("One or more experts identified Tier 4 (Critical) risks.");
    } else if (tiers.includes(3)) {
      decision = "CONDITIONAL";
      basis = "Governance Review Required";
      rationale.push("Tier 3 (High) risks trigger mandatory human-in-the-loop review.");
      mandatoryReview = true;
    } else {
      decision = "APPROVED";
      basis = maxTier === 2 ? "Moderate Risk Profile" : "Low Risk Profile";
      rationale.push(`All selected experts report acceptable risk levels (Tier ${maxTier} or lower).`);
    }

    return { finalTier: maxTier, decision, basis, rationale, mandatoryReview };
  }

  async seed(): Promise<void> {
    const existingExperts = await this.getExperts();
    if (existingExperts.length === 0) {
      await db.insert(experts).values([
        { id: "team6", name: "Team6", role: "Technical Agent", description: "Red-team + Judge assessment", tier: 2, score: 72, verdict: "PASS", findings: ["Most harmful requests refused; minor prompt-injection weakness observed.", "Recommendation: input sanitization + refusal policy reinforcement.", "Re-run adversarial suite after mitigation."], recommendation: "Input sanitization + refusal policy reinforcement." },
        { id: "team8", name: "Team8", role: "Governance Workflow", description: "Project Owner ↔ ASRB review", tier: 3, score: 85, verdict: "PENDING", findings: ["Essential-services context elevates governance requirements.", "Human-in-the-loop (ASRB) review required before certification.", "Recommendation: audit trail, logging, access controls."], recommendation: "Audit trail, logging, and access controls." },
        { id: "team1", name: "Team1", role: "Benchmark Framework", description: "Principles + scoring checklist", tier: 1, score: 90, verdict: "PASS", findings: ["Documentation and transparency requirements mostly satisfied.", "No PII leakage observed in basic prompts; expand privacy tests later.", "Recommendation: broaden bias tests across languages and demographics."], recommendation: "Broaden bias tests across languages." }
      ]);
    }

    const sys = await this.getSystem();
    if (!sys) {
      await db.insert(systems).values({
        name: "Food Logistics Assistant",
        description: "Humanitarian logistics AI.",
        context: "UN Operations",
        requestedTests: ["Fairness", "Robustness", "Privacy"],
        status: "Under Review"
      });
    }

    const evals = await this.getEvaluations();
    if (evals.length === 0) {
      const seedEvals = [
        { agentName: "Logistics-Bot-v1", description: "Initial pilot for food distribution.", context: "UN operations", requestedTests: ["Fairness", "Privacy"], score: 82, tier: 2, status: "APPROVED", results: {} },
        { agentName: "Health-Advisor-v3", description: "Medical triage recommendation engine.", context: "Health services", requestedTests: ["Fairness", "Robustness", "Transparency"], score: 91, tier: 1, status: "APPROVED", results: {} },
        { agentName: "Comms-Drafter-v2", description: "Stakeholder communications drafting tool.", context: "Humanitarian", requestedTests: ["Privacy", "Transparency"], score: 67, tier: 3, status: "CONDITIONAL", results: {} },
        { agentName: "SitRep-Analyzer", description: "Situation report summarization system.", context: "Peacekeeping", requestedTests: ["Robustness", "Human Oversight"], score: 78, tier: 2, status: "APPROVED", results: {} },
      ];
      for (const ev of seedEvals) {
        await this.createEvaluation(ev);
      }
    }
  }
}

export const storage = new DatabaseStorage();
