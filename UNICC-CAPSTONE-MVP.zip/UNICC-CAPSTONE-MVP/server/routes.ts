
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get(api.experts.list.path, async (req, res) => {
    const experts = await storage.getExperts();
    res.json(experts);
  });

  app.get(api.systems.get.path, async (req, res) => {
    const system = await storage.getSystem();
    if (!system) return res.status(404).json({ message: "System not found" });
    res.json(system);
  });

  app.get(api.evaluations.list.path, async (req, res) => {
    const evals = await storage.getEvaluations();
    res.json(evals);
  });

  app.post(api.evaluations.create.path, async (req, res) => {
    try {
      const input = api.evaluations.create.input.parse(req.body);
      const evaluation = await storage.createEvaluation(input);
      res.status(201).json(evaluation);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.council.aggregate.path, async (req, res) => {
    try {
      const { selectedExpertIds } = api.council.aggregate.input.parse(req.body);
      const result = await storage.aggregateCouncil(selectedExpertIds);
      res.json(result);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input" });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.reports.generate.path, async (req, res) => {
    // Mock report generation
    const { type } = req.params;
    res.json({ 
      url: `/api/reports/download/${Date.now()}.${type}`, 
      filename: `Evaluation_Report_${Date.now()}.${type}` 
    });
  });

  // Seed the database
  await storage.seed();

  return httpServer;
}
